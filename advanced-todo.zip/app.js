// Application State
class TodoApp {
    constructor() {
        this.tasks = [];
        this.categories = [
            { name: "Work", color: "#3b82f6", icon: "💼" },
            { name: "Personal", color: "#10b981", icon: "🏠" },
            { name: "Health", color: "#f59e0b", icon: "💪" },
            { name: "Shopping", color: "#8b5cf6", icon: "🛒" },
            { name: "Learning", color: "#ef4444", icon: "📚" }
        ];
        this.achievements = [
            { id: "first_task", name: "First Task", description: "Complete your first task", icon: "🏆", unlocked: false },
            { id: "early_bird", name: "Early Bird", description: "Complete a task before 9 AM", icon: "🌅", unlocked: false },
            { id: "streak_5", name: "5 Day Streak", description: "Complete tasks for 5 consecutive days", icon: "🔥", unlocked: false },
            { id: "productivity_master", name: "Productivity Master", description: "Complete 10 tasks in a single day", icon: "⚡", unlocked: false }
        ];
        this.userStats = {
            totalTasks: 0,
            completedTasks: 0,
            currentStreak: 0,
            totalXP: 0,
            level: 1,
            tasksCompletedToday: 0,
            currentLevelXP: 0,
            nextLevelXP: 50
        };
        this.settings = {
            theme: 'auto',
            notifications: true,
            sounds: true
        };
        this.currentView = 'dashboard';
        this.currentMonth = new Date().getMonth();
        this.currentYear = new Date().getFullYear();
        this.editingTaskId = null;
        
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.init());
        } else {
            this.init();
        }
    }

    init() {
        this.loadData();
        this.initializeDefaultTasks();
        this.bindEvents();
        this.updateUI();
        this.updateDateTime();
        
        // Update time every minute
        setInterval(() => this.updateDateTime(), 60000);
        
        console.log('App initialized successfully');
    }

    initializeDefaultTasks() {
        if (this.tasks.length === 0) {
            const sampleTasks = [
                {
                    id: this.generateId(),
                    title: "Complete project presentation",
                    description: "Prepare slides for client meeting next week",
                    priority: "high",
                    status: "todo",
                    category: "Work",
                    dueDate: "2025-09-15",
                    completed: false,
                    subtasks: [
                        { id: 1, title: "Research competitor analysis", completed: true },
                        { id: 2, title: "Create mockups", completed: false },
                        { id: 3, title: "Write executive summary", completed: false }
                    ],
                    tags: ["urgent", "presentation"],
                    createdAt: new Date().toISOString()
                },
                {
                    id: this.generateId(),
                    title: "Buy groceries",
                    description: "Weekly shopping for household items",
                    priority: "medium",
                    status: "todo",
                    category: "Personal",
                    dueDate: "2025-09-12",
                    completed: false,
                    subtasks: [
                        { id: 1, title: "Milk and eggs", completed: false },
                        { id: 2, title: "Fresh vegetables", completed: false }
                    ],
                    tags: ["shopping", "weekly"],
                    createdAt: new Date().toISOString()
                },
                {
                    id: this.generateId(),
                    title: "Morning workout",
                    description: "30-minute cardio session",
                    priority: "low",
                    status: "done",
                    category: "Health",
                    dueDate: "2025-09-11",
                    completed: true,
                    subtasks: [],
                    tags: ["fitness", "daily"],
                    createdAt: new Date().toISOString()
                }
            ];
            
            this.tasks = sampleTasks;
            this.updateUserStats();
            this.saveData();
        }
    }

    generateId() {
        return Date.now() + Math.random().toString(36).substr(2, 9);
    }

    loadData() {
        try {
            const savedTasks = localStorage.getItem('advancedTodo_tasks');
            const savedAchievements = localStorage.getItem('advancedTodo_achievements');
            const savedStats = localStorage.getItem('advancedTodo_stats');
            const savedSettings = localStorage.getItem('advancedTodo_settings');

            if (savedTasks) this.tasks = JSON.parse(savedTasks);
            if (savedAchievements) this.achievements = JSON.parse(savedAchievements);
            if (savedStats) this.userStats = JSON.parse(savedStats);
            if (savedSettings) this.settings = JSON.parse(savedSettings);
        } catch (error) {
            console.error('Error loading data:', error);
        }
    }

    saveData() {
        try {
            localStorage.setItem('advancedTodo_tasks', JSON.stringify(this.tasks));
            localStorage.setItem('advancedTodo_achievements', JSON.stringify(this.achievements));
            localStorage.setItem('advancedTodo_stats', JSON.stringify(this.userStats));
            localStorage.setItem('advancedTodo_settings', JSON.stringify(this.settings));
        } catch (error) {
            console.error('Error saving data:', error);
            this.showNotification('Unable to save data. Storage might be full.', 'error');
        }
    }

    bindEvents() {
        console.log('Binding events...');
        
        // Tab navigation with event delegation
        const navTabs = document.querySelector('.nav-tabs');
        if (navTabs) {
            navTabs.addEventListener('click', (e) => {
                const tab = e.target.closest('.nav-tab');
                if (tab && tab.dataset.tab) {
                    console.log('Tab clicked:', tab.dataset.tab);
                    this.switchTab(tab.dataset.tab);
                }
            });
        }

        // FAB button
        const fabBtn = document.getElementById('fabBtn');
        if (fabBtn) {
            fabBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                console.log('FAB clicked');
                this.openTaskModal();
            });
        }

        // Modal events
        const modalClose = document.getElementById('modalClose');
        if (modalClose) {
            modalClose.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeTaskModal();
            });
        }

        const cancelBtn = document.getElementById('cancelBtn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeTaskModal();
            });
        }

        const saveTaskBtn = document.getElementById('saveTaskBtn');
        if (saveTaskBtn) {
            saveTaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.saveTask();
            });
        }

        // Theme toggle
        const themeToggle = document.getElementById('themeToggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleTheme();
            });
        }

        // Calendar navigation
        const prevMonth = document.getElementById('prevMonth');
        if (prevMonth) {
            prevMonth.addEventListener('click', (e) => {
                e.preventDefault();
                this.changeMonth(-1);
            });
        }

        const nextMonth = document.getElementById('nextMonth');
        if (nextMonth) {
            nextMonth.addEventListener('click', (e) => {
                e.preventDefault();
                this.changeMonth(1);
            });
        }

        // Subtask management
        const addSubtaskBtn = document.getElementById('addSubtaskBtn');
        if (addSubtaskBtn) {
            addSubtaskBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.addSubtask();
            });
        }

        // Task filters and search
        const categoryFilter = document.getElementById('categoryFilter');
        if (categoryFilter) {
            categoryFilter.addEventListener('change', () => {
                this.applyFilters();
            });
        }

        const priorityFilter = document.getElementById('priorityFilter');
        if (priorityFilter) {
            priorityFilter.addEventListener('change', () => {
                this.applyFilters();
            });
        }

        const taskSearch = document.getElementById('taskSearch');
        if (taskSearch) {
            taskSearch.addEventListener('input', () => {
                this.applyFilters();
            });
        }

        // Settings
        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.addEventListener('change', (e) => {
                this.updateTheme(e.target.value);
            });
        }

        const exportData = document.getElementById('exportData');
        if (exportData) {
            exportData.addEventListener('click', (e) => {
                e.preventDefault();
                this.exportTasks();
            });
        }

        const clearData = document.getElementById('clearData');
        if (clearData) {
            clearData.addEventListener('click', (e) => {
                e.preventDefault();
                this.clearAllData();
            });
        }

        // Today's tasks toggle
        const todaysTasksToggle = document.getElementById('todaysTasksToggle');
        if (todaysTasksToggle) {
            todaysTasksToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleTodaysTasks();
            });
        }

        // Achievement modal
        const achievementOkBtn = document.getElementById('achievementOkBtn');
        if (achievementOkBtn) {
            achievementOkBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.closeAchievementModal();
            });
        }

        // Modal backdrop clicks
        const taskModal = document.getElementById('taskModal');
        if (taskModal) {
            taskModal.addEventListener('click', (e) => {
                if (e.target.id === 'taskModal') {
                    this.closeTaskModal();
                }
            });
        }

        const achievementModal = document.getElementById('achievementModal');
        if (achievementModal) {
            achievementModal.addEventListener('click', (e) => {
                if (e.target.id === 'achievementModal') {
                    this.closeAchievementModal();
                }
            });
        }

        console.log('Events bound successfully');
    }

    switchTab(tabName) {
        console.log('Switching to tab:', tabName);
        
        // Update active tab
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        const activeTab = document.querySelector(`[data-tab="${tabName}"]`);
        if (activeTab) {
            activeTab.classList.add('active');
        }

        // Show/hide content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        const activeContent = document.getElementById(tabName);
        if (activeContent) {
            activeContent.classList.add('active');
        }

        this.currentView = tabName;

        // Update specific views
        if (tabName === 'tasks') {
            this.renderKanbanBoard();
        } else if (tabName === 'calendar') {
            this.renderCalendar();
        } else if (tabName === 'analytics') {
            this.renderAnalytics();
        } else if (tabName === 'dashboard') {
            this.renderDashboard();
        }

        console.log('Tab switched to:', tabName);
    }

    updateDateTime() {
        const now = new Date();
        const options = { 
            weekday: 'long', 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        };
        const dateElement = document.getElementById('currentDate');
        if (dateElement) {
            dateElement.textContent = now.toLocaleDateString('en-US', options);
        }
    }

    openTaskModal(taskId = null) {
        console.log('Opening task modal, taskId:', taskId);
        
        this.editingTaskId = taskId;
        const modal = document.getElementById('taskModal');
        const form = document.getElementById('taskForm');
        
        if (!modal || !form) {
            console.error('Modal elements not found');
            return;
        }
        
        // Clear form
        form.reset();
        const subtasksContainer = document.getElementById('subtasksContainer');
        if (subtasksContainer) {
            subtasksContainer.innerHTML = '';
        }
        
        // Populate categories
        const categorySelect = document.getElementById('taskCategory');
        if (categorySelect) {
            categorySelect.innerHTML = '';
            this.categories.forEach(cat => {
                const option = document.createElement('option');
                option.value = cat.name;
                option.textContent = `${cat.icon} ${cat.name}`;
                categorySelect.appendChild(option);
            });
        }

        // Set default due date to today
        const dueDateInput = document.getElementById('taskDueDate');
        if (dueDateInput) {
            dueDateInput.value = new Date().toISOString().split('T')[0];
        }

        // If editing, populate form
        if (taskId) {
            const task = this.tasks.find(t => t.id === taskId);
            if (task) {
                const modalTitle = document.getElementById('modalTitle');
                if (modalTitle) modalTitle.textContent = 'Edit Task';
                
                const taskTitle = document.getElementById('taskTitle');
                if (taskTitle) taskTitle.value = task.title;
                
                const taskDescription = document.getElementById('taskDescription');
                if (taskDescription) taskDescription.value = task.description || '';
                
                const taskPriority = document.getElementById('taskPriority');
                if (taskPriority) taskPriority.value = task.priority;
                
                if (categorySelect) categorySelect.value = task.category;
                if (dueDateInput) dueDateInput.value = task.dueDate;
                
                const taskTags = document.getElementById('taskTags');
                if (taskTags) taskTags.value = task.tags.join(', ');
                
                // Populate subtasks
                task.subtasks.forEach(subtask => {
                    this.addSubtask(subtask.title);
                });
            }
        } else {
            const modalTitle = document.getElementById('modalTitle');
            if (modalTitle) modalTitle.textContent = 'Create New Task';
        }

        modal.classList.remove('hidden');
        console.log('Modal opened');
    }

    closeTaskModal() {
        const modal = document.getElementById('taskModal');
        if (modal) {
            modal.classList.add('hidden');
        }
        this.editingTaskId = null;
    }

    saveTask() {
        const titleInput = document.getElementById('taskTitle');
        const title = titleInput ? titleInput.value.trim() : '';
        
        if (!title) {
            this.showNotification('Task title is required', 'error');
            return;
        }

        const taskData = {
            title,
            description: this.getInputValue('taskDescription'),
            priority: this.getInputValue('taskPriority'),
            category: this.getInputValue('taskCategory'),
            dueDate: this.getInputValue('taskDueDate'),
            tags: this.getInputValue('taskTags').split(',').map(tag => tag.trim()).filter(tag => tag),
            subtasks: this.getSubtasksFromForm()
        };

        if (this.editingTaskId) {
            // Update existing task
            const taskIndex = this.tasks.findIndex(t => t.id === this.editingTaskId);
            if (taskIndex !== -1) {
                this.tasks[taskIndex] = { ...this.tasks[taskIndex], ...taskData };
            }
        } else {
            // Create new task
            const newTask = {
                id: this.generateId(),
                ...taskData,
                status: 'todo',
                completed: false,
                createdAt: new Date().toISOString()
            };
            this.tasks.push(newTask);
        }

        this.updateUserStats();
        this.saveData();
        this.updateUI();
        this.closeTaskModal();

        // Show success message
        this.showNotification('Task saved successfully!', 'success');
    }

    getInputValue(inputId) {
        const input = document.getElementById(inputId);
        return input ? input.value.trim() : '';
    }

    getSubtasksFromForm() {
        const subtasks = [];
        const inputs = document.querySelectorAll('.subtask-item input[type="text"]');
        inputs.forEach((input, index) => {
            if (input.value.trim()) {
                subtasks.push({
                    id: index + 1,
                    title: input.value.trim(),
                    completed: false
                });
            }
        });
        return subtasks;
    }

    addSubtask(title = '') {
        const container = document.getElementById('subtasksContainer');
        if (!container) return;
        
        const subtaskDiv = document.createElement('div');
        subtaskDiv.className = 'subtask-item';
        
        subtaskDiv.innerHTML = `
            <input type="text" placeholder="Subtask title" value="${title}">
            <button type="button" class="subtask-remove">
                <i class="fas fa-times"></i>
            </button>
        `;

        const removeBtn = subtaskDiv.querySelector('.subtask-remove');
        if (removeBtn) {
            removeBtn.addEventListener('click', () => {
                subtaskDiv.remove();
            });
        }

        container.appendChild(subtaskDiv);
    }

    toggleTask(taskId) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task) {
            task.completed = !task.completed;
            task.status = task.completed ? 'done' : 'todo';
            
            if (task.completed) {
                this.addXP(this.getTaskXP(task));
                this.checkAchievements();
                this.showTaskCompletionAnimation(taskId);
            }
            
            this.updateUserStats();
            this.saveData();
            this.updateUI();
        }
    }

    deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.updateUserStats();
            this.saveData();
            this.updateUI();
            this.showNotification('Task deleted', 'info');
        }
    }

    getTaskXP(task) {
        const baseXP = 5;
        const priorityMultiplier = {
            'low': 1,
            'medium': 1.5,
            'high': 2
        };
        return Math.floor(baseXP * priorityMultiplier[task.priority]);
    }

    addXP(amount) {
        this.userStats.totalXP += amount;
        this.userStats.currentLevelXP += amount;
        
        // Check for level up
        while (this.userStats.currentLevelXP >= this.userStats.nextLevelXP) {
            this.userStats.currentLevelXP -= this.userStats.nextLevelXP;
            this.userStats.level++;
            this.userStats.nextLevelXP = this.userStats.level * 50;
            this.showNotification(`Level up! You're now level ${this.userStats.level}! 🎉`, 'success');
        }
    }

    updateUserStats() {
        const completedTasks = this.tasks.filter(t => t.completed);
        const today = new Date().toISOString().split('T')[0];
        const completedToday = completedTasks.filter(t => 
            t.createdAt && t.createdAt.split('T')[0] === today
        );

        this.userStats.totalTasks = this.tasks.length;
        this.userStats.completedTasks = completedTasks.length;
        this.userStats.tasksCompletedToday = completedToday.length;
        
        // Update streak calculation
        this.calculateStreak();
    }

    calculateStreak() {
        const today = new Date();
        let streak = 0;
        let currentDate = new Date(today);
        
        while (true) {
            const dateStr = currentDate.toISOString().split('T')[0];
            const dayTasks = this.tasks.filter(t => 
                t.completed && t.createdAt && t.createdAt.split('T')[0] === dateStr
            );
            
            if (dayTasks.length > 0) {
                streak++;
                currentDate.setDate(currentDate.getDate() - 1);
            } else {
                break;
            }
        }
        
        this.userStats.currentStreak = streak;
    }

    checkAchievements() {
        // First task achievement
        if (!this.achievements.find(a => a.id === 'first_task')?.unlocked && this.userStats.completedTasks >= 1) {
            this.unlockAchievement('first_task');
        }

        // 5 day streak achievement
        if (!this.achievements.find(a => a.id === 'streak_5')?.unlocked && this.userStats.currentStreak >= 5) {
            this.unlockAchievement('streak_5');
        }

        // Productivity master achievement
        if (!this.achievements.find(a => a.id === 'productivity_master')?.unlocked && this.userStats.tasksCompletedToday >= 10) {
            this.unlockAchievement('productivity_master');
        }

        // Early bird achievement (check if completed before 9 AM)
        const now = new Date();
        if (!this.achievements.find(a => a.id === 'early_bird')?.unlocked && now.getHours() < 9) {
            this.unlockAchievement('early_bird');
        }
    }

    unlockAchievement(achievementId) {
        const achievement = this.achievements.find(a => a.id === achievementId);
        if (achievement && !achievement.unlocked) {
            achievement.unlocked = true;
            achievement.unlockedAt = new Date().toISOString();
            this.addXP(10); // Bonus XP for achievements
            this.showAchievementModal(achievement);
            this.saveData();
        }
    }

    showAchievementModal(achievement) {
        const iconEl = document.getElementById('achievementIcon');
        const nameEl = document.getElementById('achievementName');
        const descEl = document.getElementById('achievementDescription');
        const modalEl = document.getElementById('achievementModal');
        
        if (iconEl) iconEl.textContent = achievement.icon;
        if (nameEl) nameEl.textContent = achievement.name;
        if (descEl) descEl.textContent = achievement.description;
        if (modalEl) modalEl.classList.remove('hidden');
    }

    closeAchievementModal() {
        const modal = document.getElementById('achievementModal');
        if (modal) {
            modal.classList.add('hidden');
        }
    }

    renderDashboard() {
        console.log('Rendering dashboard...');
        
        // Update stats
        this.updateElement('totalTasksStat', this.userStats.totalTasks);
        this.updateElement('completedTodayStat', this.userStats.tasksCompletedToday);
        this.updateElement('pendingStat', this.tasks.filter(t => !t.completed).length);
        this.updateElement('streakStat', this.userStats.currentStreak);

        // Update level info
        this.updateElement('userLevel', this.userStats.level);
        this.updateElement('currentXP', this.userStats.currentLevelXP);
        this.updateElement('nextLevelXP', this.userStats.nextLevelXP);
        
        const progressPercentage = (this.userStats.currentLevelXP / this.userStats.nextLevelXP) * 100;
        const levelProgressBar = document.getElementById('levelProgressBar');
        if (levelProgressBar) {
            levelProgressBar.style.width = `${progressPercentage}%`;
        }

        // Update progress circle
        const completionPercentage = this.userStats.totalTasks > 0 ? 
            Math.round((this.userStats.completedTasks / this.userStats.totalTasks) * 100) : 0;
        this.updateElement('progressPercentage', `${completionPercentage}%`);
        
        const progressCircle = document.getElementById('progressCircle');
        if (progressCircle) {
            const angle = (completionPercentage / 100) * 360;
            progressCircle.style.background = `conic-gradient(var(--color-primary) ${angle}deg, var(--color-secondary) ${angle}deg)`;
        }

        // Update motivational message
        const messages = [
            "Great start! Keep up the momentum! 💪",
            "You're doing amazing! 🌟",
            "Productivity champion! 🏆",
            "Keep crushing those goals! 🚀",
            "Fantastic progress! 🎯"
        ];
        this.updateElement('motivationalMessage', messages[Math.floor(Math.random() * messages.length)]);

        // Render today's tasks and achievements
        this.renderTodaysTasks();
        this.renderAchievements();
    }

    updateElement(id, content) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = content;
        }
    }

    renderTodaysTasks() {
        const today = new Date().toISOString().split('T')[0];
        const todaysTasks = this.tasks.filter(t => t.dueDate === today);
        const container = document.getElementById('todaysTasksList');
        
        if (!container) return;
        
        if (todaysTasks.length === 0) {
            container.innerHTML = '<p class="empty-state">No tasks due today. Great job! 🎉</p>';
            return;
        }

        container.innerHTML = todaysTasks.map(task => this.createTaskCardHTML(task)).join('');
        this.bindTaskCardEvents();
    }

    renderAchievements() {
        const container = document.getElementById('achievementsGrid');
        if (!container) return;
        
        container.innerHTML = this.achievements.map(achievement => `
            <div class="achievement-card ${achievement.unlocked ? 'unlocked' : ''}">
                <div class="achievement-icon">${achievement.icon}</div>
                <h4 class="achievement-name">${achievement.name}</h4>
                <p class="achievement-description">${achievement.description}</p>
                ${achievement.unlocked ? '<div class="status status--success">Unlocked</div>' : ''}
            </div>
        `).join('');
    }

    renderKanbanBoard() {
        console.log('Rendering Kanban board...');
        
        // Populate category filter - Fixed to show all categories
        this.populateCategoryFilter();
        this.applyFilters();
    }

    populateCategoryFilter() {
        const categoryFilter = document.getElementById('categoryFilter');
        if (!categoryFilter) return;
        
        // Clear existing options
        categoryFilter.innerHTML = '';
        
        // Add "All Categories" option
        const allOption = document.createElement('option');
        allOption.value = '';
        allOption.textContent = 'All Categories';
        categoryFilter.appendChild(allOption);
        
        // Add each category option
        this.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.name;
            option.textContent = `${category.icon} ${category.name}`;
            categoryFilter.appendChild(option);
        });
    }

    applyFilters() {
        const categoryFilter = document.getElementById('categoryFilter');
        const priorityFilter = document.getElementById('priorityFilter');
        const taskSearch = document.getElementById('taskSearch');
        
        const categoryFilterValue = categoryFilter ? categoryFilter.value : '';
        const priorityFilterValue = priorityFilter ? priorityFilter.value : '';
        const searchTerm = taskSearch ? taskSearch.value.toLowerCase() : '';

        let filteredTasks = this.tasks.filter(task => {
            const matchesCategory = !categoryFilterValue || task.category === categoryFilterValue;
            const matchesPriority = !priorityFilterValue || task.priority === priorityFilterValue;
            const matchesSearch = !searchTerm || 
                task.title.toLowerCase().includes(searchTerm) ||
                task.description.toLowerCase().includes(searchTerm) ||
                task.tags.some(tag => tag.toLowerCase().includes(searchTerm));

            return matchesCategory && matchesPriority && matchesSearch;
        });

        // Group by status
        const todoTasks = filteredTasks.filter(t => t.status === 'todo');
        const inProgressTasks = filteredTasks.filter(t => t.status === 'inprogress');
        const doneTasks = filteredTasks.filter(t => t.status === 'done');

        // Update counters
        this.updateElement('todoCount', todoTasks.length);
        this.updateElement('inprogressCount', inProgressTasks.length);
        this.updateElement('doneCount', doneTasks.length);

        // Render columns
        const todoColumn = document.getElementById('todoColumn');
        const inprogressColumn = document.getElementById('inprogressColumn');
        const doneColumn = document.getElementById('doneColumn');
        
        if (todoColumn) todoColumn.innerHTML = todoTasks.map(task => this.createKanbanTaskHTML(task)).join('');
        if (inprogressColumn) inprogressColumn.innerHTML = inProgressTasks.map(task => this.createKanbanTaskHTML(task)).join('');
        if (doneColumn) doneColumn.innerHTML = doneTasks.map(task => this.createKanbanTaskHTML(task)).join('');

        this.bindTaskCardEvents();
        this.enableDragAndDrop();
    }

    createTaskCardHTML(task) {
        const subtasksCompleted = task.subtasks.filter(st => st.completed).length;
        const subtasksTotal = task.subtasks.length;
        
        return `
            <div class="task-card priority-${task.priority} ${task.completed ? 'completed' : ''}" data-task-id="${task.id}">
                <div class="task-header">
                    <div class="task-title-section">
                        <h4 class="task-title ${task.completed ? 'completed' : ''}">${task.title}</h4>
                        <div class="task-meta">
                            <span>${this.categories.find(c => c.name === task.category)?.icon || '📝'} ${task.category}</span>
                            <span>📅 ${new Date(task.dueDate).toLocaleDateString()}</span>
                            <span class="priority-badge priority-${task.priority}">
                                ${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                            </span>
                        </div>
                    </div>
                    <div class="task-actions">
                        <button class="task-toggle-btn" data-task-id="${task.id}" title="${task.completed ? 'Mark incomplete' : 'Mark complete'}">
                            <i class="fas ${task.completed ? 'fa-undo' : 'fa-check'}"></i>
                        </button>
                        <button class="task-edit-btn" data-task-id="${task.id}" title="Edit task">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="task-delete-btn" data-task-id="${task.id}" title="Delete task">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
                ${task.description ? `<p class="task-description">${task.description}</p>` : ''}
                ${subtasksTotal > 0 ? `<div class="subtasks-progress">Subtasks: ${subtasksCompleted}/${subtasksTotal}</div>` : ''}
                ${task.tags.length > 0 ? `
                    <div class="task-tags">
                        ${task.tags.map(tag => `<span class="task-tag">${tag}</span>`).join('')}
                    </div>
                ` : ''}
            </div>
        `;
    }

    createKanbanTaskHTML(task) {
        return `
            <div class="kanban-task priority-${task.priority}" data-task-id="${task.id}" draggable="true">
                <div class="task-header">
                    <div class="task-title-section">
                        <h5 class="task-title">${task.title}</h5>
                        <div class="task-meta">
                            <span>${this.categories.find(c => c.name === task.category)?.icon || '📝'}</span>
                            <span>📅 ${new Date(task.dueDate).toLocaleDateString()}</span>
                        </div>
                    </div>
                    <div class="task-actions">
                        <button class="task-edit-btn" data-task-id="${task.id}" title="Edit task">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="task-delete-btn" data-task-id="${task.id}" title="Delete task">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    bindTaskCardEvents() {
        // Use event delegation for task actions
        document.addEventListener('click', (e) => {
            const target = e.target.closest('button');
            if (!target) return;

            const taskId = target.dataset.taskId;
            if (!taskId) return;

            if (target.classList.contains('task-toggle-btn')) {
                e.preventDefault();
                this.toggleTask(taskId);
            } else if (target.classList.contains('task-edit-btn')) {
                e.preventDefault();
                this.openTaskModal(taskId);
            } else if (target.classList.contains('task-delete-btn')) {
                e.preventDefault();
                this.deleteTask(taskId);
            }
        });
    }

    enableDragAndDrop() {
        const tasks = document.querySelectorAll('.kanban-task');
        const columns = document.querySelectorAll('.column-content');

        tasks.forEach(task => {
            task.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', task.dataset.taskId);
                task.classList.add('dragging');
            });

            task.addEventListener('dragend', () => {
                task.classList.remove('dragging');
            });
        });

        columns.forEach(column => {
            column.addEventListener('dragover', (e) => {
                e.preventDefault();
                column.classList.add('drag-over');
            });

            column.addEventListener('dragleave', () => {
                column.classList.remove('drag-over');
            });

            column.addEventListener('drop', (e) => {
                e.preventDefault();
                const taskId = e.dataTransfer.getData('text/plain');
                const newStatus = column.parentElement.dataset.status;
                
                this.moveTask(taskId, newStatus);
                column.classList.remove('drag-over');
            });
        });
    }

    moveTask(taskId, newStatus) {
        const task = this.tasks.find(t => t.id === taskId);
        if (task && task.status !== newStatus) {
            task.status = newStatus;
            task.completed = newStatus === 'done';
            
            if (task.completed) {
                this.addXP(this.getTaskXP(task));
                this.checkAchievements();
            }
            
            this.updateUserStats();
            this.saveData();
            this.applyFilters(); // Refresh the kanban board
            this.showNotification('Task moved successfully!', 'success');
        }
    }

    renderCalendar() {
        console.log('Rendering calendar...');
        
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];
        
        this.updateElement('currentMonth', `${monthNames[this.currentMonth]} ${this.currentYear}`);

        const firstDay = new Date(this.currentYear, this.currentMonth, 1);
        const lastDay = new Date(this.currentYear, this.currentMonth + 1, 0);
        const startDate = new Date(firstDay);
        startDate.setDate(startDate.getDate() - firstDay.getDay());

        const calendar = document.getElementById('calendarGrid');
        if (!calendar) return;
        
        calendar.innerHTML = '';

        // Add day headers
        const dayHeaders = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        dayHeaders.forEach(day => {
            const dayHeader = document.createElement('div');
            dayHeader.className = 'calendar-day-header';
            dayHeader.textContent = day;
            calendar.appendChild(dayHeader);
        });

        // Add calendar days
        for (let i = 0; i < 42; i++) {
            const currentDate = new Date(startDate);
            currentDate.setDate(startDate.getDate() + i);
            
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            
            if (currentDate.getMonth() !== this.currentMonth) {
                dayElement.classList.add('other-month');
            }
            
            if (this.isToday(currentDate)) {
                dayElement.classList.add('today');
            }

            const dayTasks = this.getTasksForDate(currentDate);
            
            dayElement.innerHTML = `
                <div class="day-number">${currentDate.getDate()}</div>
                <div class="day-tasks">
                    ${dayTasks.map(task => `
                        <div class="day-task-dot ${task.priority}-priority" title="${task.title}"></div>
                    `).join('')}
                </div>
            `;

            dayElement.addEventListener('click', () => {
                this.openTaskModal();
                const dueDateInput = document.getElementById('taskDueDate');
                if (dueDateInput) {
                    dueDateInput.value = currentDate.toISOString().split('T')[0];
                }
            });

            calendar.appendChild(dayElement);
        }
    }

    changeMonth(direction) {
        this.currentMonth += direction;
        if (this.currentMonth > 11) {
            this.currentMonth = 0;
            this.currentYear++;
        } else if (this.currentMonth < 0) {
            this.currentMonth = 11;
            this.currentYear--;
        }
        this.renderCalendar();
    }

    isToday(date) {
        const today = new Date();
        return date.toDateString() === today.toDateString();
    }

    getTasksForDate(date) {
        const dateString = date.toISOString().split('T')[0];
        return this.tasks.filter(task => task.dueDate === dateString);
    }

    renderAnalytics() {
        console.log('Rendering analytics...');
        
        // Category distribution
        const categoryStats = {};
        this.tasks.forEach(task => {
            categoryStats[task.category] = (categoryStats[task.category] || 0) + 1;
        });

        const categoryStatsContainer = document.getElementById('categoryStats');
        if (categoryStatsContainer) {
            categoryStatsContainer.innerHTML = Object.entries(categoryStats)
                .map(([category, count]) => {
                    const categoryInfo = this.categories.find(c => c.name === category);
                    return `
                        <div class="category-stat">
                            <span>${categoryInfo?.icon || '📝'} ${category}</span>
                            <span><strong>${count}</strong> tasks</span>
                        </div>
                    `;
                }).join('');
        }
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-color-scheme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.updateTheme(newTheme);
        this.settings.theme = newTheme;
        this.saveData();
    }

    updateTheme(theme) {
        if (theme === 'auto') {
            document.documentElement.removeAttribute('data-color-scheme');
        } else {
            document.documentElement.setAttribute('data-color-scheme', theme);
        }
        
        // Update theme toggle icon
        const themeIcon = document.querySelector('#themeToggle i');
        if (themeIcon) {
            themeIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        
        // Update settings
        const themeSelect = document.getElementById('themeSelect');
        if (themeSelect) {
            themeSelect.value = theme;
        }
        this.settings.theme = theme;
    }

    toggleTodaysTasks() {
        const tasksList = document.getElementById('todaysTasksList');
        const toggleBtn = document.getElementById('todaysTasksToggle');
        
        if (!tasksList || !toggleBtn) return;
        
        const isHidden = tasksList.style.display === 'none';
        
        tasksList.style.display = isHidden ? 'flex' : 'none';
        const icon = toggleBtn.querySelector('i');
        if (icon) {
            icon.className = isHidden ? 'fas fa-chevron-up' : 'fas fa-chevron-down';
        }
    }

    showTaskCompletionAnimation(taskId) {
        const taskCard = document.querySelector(`[data-task-id="${taskId}"]`);
        if (taskCard) {
            taskCard.style.animation = 'bounce 0.6s ease-in-out';
            setTimeout(() => {
                taskCard.style.animation = '';
            }, 600);
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 20px;
            background: var(--color-${type === 'success' ? 'success' : type === 'error' ? 'error' : 'info'});
            color: white;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 10000;
            animation: slideIn 0.3s ease-out;
            max-width: 300px;
        `;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease-out';
            setTimeout(() => {
                if (document.body.contains(notification)) {
                    document.body.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }

    exportTasks() {
        const dataStr = JSON.stringify({
            tasks: this.tasks,
            achievements: this.achievements,
            userStats: this.userStats,
            exportDate: new Date().toISOString()
        }, null, 2);
        
        const dataBlob = new Blob([dataStr], { type: 'application/json' });
        const url = URL.createObjectURL(dataBlob);
        
        const link = document.createElement('a');
        link.href = url;
        link.download = 'advanced-todo-export.json';
        link.click();
        
        URL.revokeObjectURL(url);
        this.showNotification('Tasks exported successfully!', 'success');
    }

    clearAllData() {
        if (confirm('Are you sure you want to clear all data? This cannot be undone.')) {
            localStorage.removeItem('advancedTodo_tasks');
            localStorage.removeItem('advancedTodo_achievements');
            localStorage.removeItem('advancedTodo_stats');
            localStorage.removeItem('advancedTodo_settings');
            
            location.reload();
        }
    }

    updateUI() {
        if (this.currentView === 'dashboard') {
            this.renderDashboard();
        } else if (this.currentView === 'tasks') {
            this.renderKanbanBoard();
        } else if (this.currentView === 'calendar') {
            this.renderCalendar();
        } else if (this.currentView === 'analytics') {
            this.renderAnalytics();
        }
    }
}

// Initialize the app
window.app = new TodoApp();

// Global functions for backwards compatibility
window.toggleTask = (taskId) => window.app.toggleTask(taskId);
window.editTask = (taskId) => window.app.openTaskModal(taskId);
window.deleteTask = (taskId) => window.app.deleteTask(taskId);

// Add CSS animations dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
    
    .drag-over {
        background-color: var(--color-bg-1) !important;
        border: 2px dashed var(--color-primary) !important;
    }
    
    .empty-state {
        text-align: center;
        color: var(--color-text-secondary);
        font-style: italic;
        padding: 40px 20px;
    }
    
    .priority-badge {
        font-size: 10px;
        padding: 2px 6px;
        border-radius: 12px;
        font-weight: 600;
        text-transform: uppercase;
    }
    
    .priority-high { color: var(--color-error); }
    .priority-medium { color: var(--color-warning); }
    .priority-low { color: var(--color-success); }
    
    .calendar-day-header {
        padding: var(--space-8);
        text-align: center;
        font-weight: var(--font-weight-semibold);
        background: var(--color-secondary);
        color: var(--color-text);
        border-bottom: 1px solid var(--color-border);
    }
    
    /* Remove blue tap highlights */
    * {
        -webkit-tap-highlight-color: transparent;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
    }
    
    input, textarea {
        -webkit-user-select: text;
        -khtml-user-select: text;
        -moz-user-select: text;
        -ms-user-select: text;
        user-select: text;
    }
`;
document.head.appendChild(style);